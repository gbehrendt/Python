import time
import urllib2
import numpy as np

# Thingspeak API key:
myAPI = 'OIFG07IRXMIGY508'
# URL where we will send the data, don't change it
baseURL = 'https://api.thingspeak.com/update?api_key=%s' % myAPI

while True:
	# generating random data
	data1=np.random.normal()
	data2=np.random.normal()
	
	print 'data1 = ', data1
	print 'data2 = ', data2
	
	try:
		conn = urllib2.urlopen(baseURL + '&field1=%s&field2=%s' % (data1, data2))	# opening the connection
		print conn.read()
		conn.close() 			# closing the connecton
	except:
		pass
		
	time.sleep(10)	# sleep for 10 seconds
