import RPi.GPIO as GPIO
import time

#GPIO.setmode(GPIO.BOARD)
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

#GPIO.setup(11,GPIO.OUT)	# setting gpio pin #11 to output
#GPIO.setup(12,GPIO.OUT) # setting gpio pin #11 to output

led_green = 17
led_red = 18
GPIO.setup(led_green,GPIO.OUT)	# setting gpio pin #11 to output
GPIO.setup(led_red,GPIO.OUT) # setting gpio pin #11 to output


'''
# Red Light
print "LED on"
GPIO.output(11,GPIO.HIGH)
time.sleep(5)
print "LED off"
GPIO.output(11,GPIO.LOW)

#Green Light
print "LED on"
GPIO.output(12,GPIO.HIGH)
time.sleep(5)
print "LED off"
GPIO.output(12,GPIO.LOW)

GPIO.cleanup() # make sure to reset all pins upon exit
'''


try:
	while True:
		print "LED on"
		GPIO.output(led_green,GPIO.HIGH)
		time.sleep(3)
		print "LED off"
		GPIO.output(led_green,GPIO.LOW)
		time.sleep(3)
		print "LED on"
		GPIO.output(led_red,GPIO.HIGH)
		time.sleep(3)
		print "LED off"
		GPIO.output(led_red,GPIO.LOW)
		time.sleep(3)
		
except:	
	print 'Exiting Program!'
	GPIO.cleanup() # make sure to reset all pins upon exit
