import RPi.GPIO as GPIO
import Adafruit_DHT 	# install with "sudo pip install Adafruit_DHT" from your RPi
import time
import datetime
import sys


def C2F(C): # function for converting from C to F
	F = C*9/5.0 + 32.0
	return F


dht11_pin=21 		# GPIO pin 21

# initialize GPIO
#GPIO.setmode(GPIO.BOARD)
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(dht11_pin,GPIO.IN)	
	
sensorType=11 		# specify the type of DHT (11) sensor
degree_sign= u'\N{DEGREE SIGN}'



while True:
	ts = time.time()
	st = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
	humidity, temperature = Adafruit_DHT.read_retry(sensorType,dht11_pin) # default temperature is C
	print 'Data reading at ', st
	print '\ttemperature = ', C2F(temperature), degree_sign, 'F'
	print '\thumidity    = ', humidity, '%\n'
	
	execfile("led.py")
	
	time.sleep(3)			# sleep for 20 seconds

GPIO.cleanup()
