import RPi.GPIO as GPIO
import Adafruit_DHT 	# install with "sudo pip install Adafruit_DHT" from your RPi
import time
import urllib2
import numpy as np
import datetime

def C2F(C): # function for converting from C to F
	F = C*9/5.0 + 32.0
	return F
  
dht11_pin=21 		# GPIO pin 21

# initialize GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(dht11_pin,GPIO.IN)	
	
sensorType=11 		# specify the type of DHT (11) sensor
degree_sign= u'\N{DEGREE SIGN}'

# LED setup
led_green = 17
led_red = 18
GPIO.setup(led_green,GPIO.OUT)	# setting gpio pin #11 to output
GPIO.setup(led_red,GPIO.OUT) # setting gpio pin #11 to output

# Thingspeak API key:
myAPI = 'OIFG07IRXMIGY508'
# URL where we will send the data, don't change it
baseURL = 'https://api.thingspeak.com/update?api_key=%s' % myAPI

try:
	while True:
		GPIO.output(led_green,GPIO.HIGH) #Green light on
		# Reading temp and humidity
		ts = time.time()
		st = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
		humidity, temperature = Adafruit_DHT.read_retry(sensorType,dht11_pin) # default temperature is C
		print 'Data reading at ', st
		print '\ttemperature = ', C2F(temperature), degree_sign, 'F'
		print '\thumidity    = ', humidity, '%\n'
		try:
			conn = urllib2.urlopen(baseURL + '&field1=%s&field2=%s' % (C2F(temperature), humidity))	# opening the connection
			#print conn.read()
			conn.close() 			# closing the connecton
			
		except:
			pass
		time.sleep(5)
		GPIO.output(led_green,GPIO.LOW) #Green light off
		GPIO.output(led_red,GPIO.HIGH) #Red light on
		time.sleep(10)	# sleep for 5 minutes
		GPIO.output(led_red,GPIO.LOW) #Red light off
		
except:
	GPIO.cleanup()	

