# This script provides basic stepper motor control using the L239D chip. 
# CW and counter CCW are referenced when looking at the motor from the shaft side. 

import RPi.GPIO as GPIO	
import time

# Setting the GPIO pin description to BCM and turning off warnigns
GPIO.setmode(GPIO.BCM)			
GPIO.setwarnings(False)	

# Pin assignments
# Variable      RPi (BCM)		L239D (pin #)
enable_pin 		= 26			# 1
coil_A_1_pin	= 4				# 2
coil_A_2_pin	= 17			# 7
coil_B_1_pin	= 23			# 15
coil_B_2_pin 	= 24			# 10

# Setting GPIO pins to output mode
GPIO.setup(enable_pin, GPIO.OUT)
GPIO.setup(coil_A_1_pin, GPIO.OUT)
GPIO.setup(coil_A_2_pin, GPIO.OUT)
GPIO.setup(coil_B_1_pin, GPIO.OUT)
GPIO.setup(coil_B_2_pin, GPIO.OUT)

# Enable the motor
GPIO.output(enable_pin, 1)

def CCW(delay, steps):  
	for i in range(0, steps):
		setStep(1, 0, 1, 0)
		time.sleep(delay)
		setStep(0, 1, 1, 0)
		time.sleep(delay)
		setStep(0, 1, 0, 1)
		time.sleep(delay)
		setStep(1, 0, 0, 1)
		time.sleep(delay)
 
def CW(delay, steps):  
	for i in range(0, steps):
		setStep(1, 0, 0, 1)
		time.sleep(delay)
		setStep(0, 1, 0, 1)
		time.sleep(delay)
		setStep(0, 1, 1, 0)
		time.sleep(delay)
		setStep(1, 0, 1, 0)
		time.sleep(delay)
 
def setStep(w1, w2, w3, w4):
	GPIO.output(coil_A_1_pin, w1)
	GPIO.output(coil_A_2_pin, w2)
	GPIO.output(coil_B_1_pin, w3)
	GPIO.output(coil_B_2_pin, w4)


try:
	while True:
		time.sleep(2)
		delay = 5.0/1000 		# milliseconds
		print 'Moving 128 steps CW.'
		CW(delay, 128)
		time.sleep(2)
		print 'Moving 128 steps CCW (back to home).'
		CCW(delay, 128)
		time.sleep(2)
		print 'Moving 128 steps CCW.'
		CCW(delay,128)
		time.sleep(2)
		print 'Moving 128 steps CW (back to home)'
		CW(delay,128)
		time.sleep(2)
except:
	setStep(0,0,0,0)
	gpio.cleanup()
	
# Note:
# When the steppers are not moving, they are still 'activated' and hold 
# their position. This draws power. If you don't need the steppers to 
# 'hold' their position, you can call setStep(0,0,0,0) to release the 
# coils. The motor will spin freely and wont draw a lot of current.


