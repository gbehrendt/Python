# This script allows a laptop or phone to connect to your RPi via wifi 
# to send commands and recieve messages. Place and execute this script on 
# your Windows or Mac laptop or phone. You will need to have Python 2.7 
# installed on your machine to do so. A good program for running python 
# code on Android devices is QPython, which is available in the google 
# play store. If you are using an iOS device look and see whatis availble.

import socket

TCP_IP = '172.23.11.199' # enter your RPi address here. 
TCP_PORT = 5005
BUFFER_SIZE = 1024



while 1:

	s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	s.connect((TCP_IP, TCP_PORT))
	MESSAGE_to = raw_input("Input command (a to CW normal, b to CCW normal, c to close, d to CCW fast, e to CW fast, h to go home,hf to go home fast, n to define new home): ")




	if MESSAGE_to == 'q':
		break
	elif MESSAGE_to == 'c':
		s.send(MESSAGE_to)
		break
	else:
		s.send(MESSAGE_to)

	MESSAGE_from = s.recv(BUFFER_SIZE)
	if MESSAGE_from > 0:
		print '\t' + MESSAGE_from

s.close()
