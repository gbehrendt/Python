# This script setups a TCP connection to permit a network device to 
# communicate to the RPi. Place and execute this script on the RPi.

import socket
from socket import SHUT_RDWR
import time
import RPi.GPIO as gpio	
import sys
import myFuncs

# Setting the GPIO pin description to BCM and turning off warnigns
gpio.setmode(gpio.BCM)			
gpio.setwarnings(False)	
'''
# Pin assignments
# Variable      RPi (BCM)		L239D (pin #)
enable_pin 	= 26			# 1
coil_A_1_pin	= 4			# 2
coil_A_2_pin	= 17			# 7
coil_B_1_pin	= 23			# 15
coil_B_2_pin 	= 24			# 10
green           = 13
red             = 19
yeller          = 5
azul            = 6

# Setting GPIO pins to output mode
gpio.setup(enable_pin, gpio.OUT)
gpio.setup(coil_A_1_pin, gpio.OUT)
gpio.setup(coil_A_2_pin, gpio.OUT)
gpio.setup(coil_B_1_pin, gpio.OUT)
gpio.setup(coil_B_2_pin, gpio.OUT)
gpio.setup(green,gpio.OUT)
gpio.setup(red,gpio.OUT) 
gpio.setup(yeller,gpio.OUT)
gpio.setup(azul,gpio.OUT) 

# Enable the motor
gpio.output(enable_pin,1)
'''
# close an open port with
# sudo fuser -KILL -k -n tcp <port>



server_ip = myFuncs.getIP()
print 'Current IP: ', server_ip

TCP_IP = server_ip
TCP_PORT = 5005
BUFFER_SIZE = 1024  # Normally 1024, but we want fast response

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((TCP_IP, TCP_PORT))
s.listen(1)

counter=0


try:
    while 1:
        conn, addr = s.accept()
        data = conn.recv(BUFFER_SIZE) # will a string
        if len(data) > 0:
            if data=='a':
                #myFuncs.CW(5.0/1000,128)  #CW Normal Speed
                stepfuncs.CCW(delay, 500)
                print 'okau'
                #counter=counter+128
                conn.send('Valid request!')
            elif data=='b':
                myFuncs.CCW(5.0/1000,128) #CCW Normal Speed
                counter=counter-128
                conn.send('Valid request!')
            elif data=='d':
                myFuncs.CCW(2.0/1000,128) #CCW Fast Speed
                counter=counter-128
                conn.send('Valid request!')
            elif data=='e':
                myFuncs.CW(2.0/1000,128) #CW Fast Speed
                counter=counter+128
                conn.send('Valid request!')
            elif data=='h':
                myFuncs.Gohome(counter) #Move motor to home position
                conn.send('Valid request!')
                counter=0
            elif data=='hf':
                myFuncs.Gohomefast(counter) #Move motor to home position FAST
                conn.send('Valid request!')
                counter=0
            elif data=='n':
                counter=0
                conn.send('Valid request!')
            elif data == 'c':
                conn.send('Closing network connecton.') # send message to the client
                gpio.cleanup()
                time.sleep(1)
                time.sleep(1)
                conn.close()
                time.sleep(1)
                sys.exit()
            else:
                conn.send('Invalid request!') 
      
except:      
    conn.send('Closing network connecton.')
    try:
        gpio.cleanup()
        time.sleep(1)
        time.sleep(1)
        conn.close()
        time.sleep(1)
    except:
        pass
