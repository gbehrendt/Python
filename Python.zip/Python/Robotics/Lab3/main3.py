
# This script provides basic stepper motor control using the L239D chip. 
# CW and counter CCW are referenced when looking at the motor from the shaft side. 

import RPi.GPIO as GPIO	
import time
import myFuncs

# Setting the GPIO pin description to BCM and turning off warnigns
GPIO.setmode(GPIO.BCM)			
GPIO.setwarnings(False)	

# Pin assignments
# Variable      RPi (BCM)		L239D (pin #)
enable_pin 		= 26			# 1
coil_A_1_pin	= 4				# 2
coil_A_2_pin	= 17			# 7
coil_B_1_pin	= 23			# 15
coil_B_2_pin 	= 24			# 10
green           = 13
red             = 19
yeller          = 5
azul            = 6

# Setting GPIO pins to output mode
GPIO.setup(enable_pin, GPIO.OUT)
GPIO.setup(coil_A_1_pin, GPIO.OUT)
GPIO.setup(coil_A_2_pin, GPIO.OUT)
GPIO.setup(coil_B_1_pin, GPIO.OUT)
GPIO.setup(coil_B_2_pin, GPIO.OUT)
GPIO.setup(green,GPIO.OUT)
GPIO.setup(red,GPIO.OUT) 
GPIO.setup(yeller,GPIO.OUT)
GPIO.setup(azul,GPIO.OUT) 

# Enable the motor
GPIO.output(enable_pin, 1)

try:
	while True:
		myFuncs.stop_motor(enable_pin)
		delay = 5.0/1000 		# milliseconds
		smalldelay = 2.0/1000   #Faster speed
		
		#Run Motor Normal Speed
		myFuncs.CW(delay, 128)
		myFuncs.stop_motor(enable_pin)
		myFuncs.CCW(delay, 128)
		myFuncs.stop_motor(enable_pin)
		myFuncs.CCW(delay,128)
		myFuncs.stop_motor(enable_pin)
		myFuncs.CW(delay,128)
		myFuncs.stop_motor(enable_pin)
		
		#Run Motor Faster
		myFuncs.CW(smalldelay, 128)
		myFuncs.stop_motor(enable_pin)
		myFuncs.CCW(smalldelay, 128)
		myFuncs.stop_motor(enable_pin)
		myFuncs.CCW(smalldelay,128)
		myFuncs.stop_motor(enable_pin)
		myFuncs.CW(smalldelay,128)
		myFuncs.stop_motor(enable_pin)
		print 'End of Program'
		
except:
	myFuncs.setStep(0,0,0,0)
	GPIO.cleanup()
	
# Note:
# When the steppers are not moving, they are still 'activated' and hold 
# their position. This draws power. If you don't need the steppers to 
# 'hold' their position, you can call setStep(0,0,0,0) to release the 
# coils. The motor will spin freely and wont draw a lot of current.


