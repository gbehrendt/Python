# This script provides basic DC motor control using the L239D chip. The
# script changes the direction and speed of the motor using 
# pulse width modulation (PWM).

import RPi.GPIO as GPIO	# modulue to control the gpio pins
import time

# Function to stop the motor
def stop_motor(enable_pin):
	print "Stopping motor"
	GPIO.output(enable_pin,GPIO.LOW)
	time.sleep(2)
	
# Setting the GPIO pin description to BCM and turning off warnigns
GPIO.setmode(GPIO.BCM)			
GPIO.setwarnings(False)	

# RPi pin assignments
# Variable      RPi (BCM)		L239D (pin #)
motor1_enable 	= 21			# 1
motor_pos 		= 20			# 2
motor_neg 		= 16			# 7
red             = 6
yeller          = 13
green           = 19
blue            = 26

# Setting GPIO pins to output mode
GPIO.setup(motor1_enable,GPIO.OUT) 
GPIO.setup(motor_pos,GPIO.OUT) 
GPIO.setup(motor_neg,GPIO.OUT) 
GPIO.setup(red,GPIO.OUT)
GPIO.setup(yeller,GPIO.OUT)
GPIO.setup(green,GPIO.OUT)
GPIO.setup(blue,GPIO.OUT)

freq=100						  	# Setting the RPi PWM frequency to 100 Hz
pwm=GPIO.PWM(motor_pos, freq)   # Initialize PWM on motor_pos pin
dc=50                             	# Setting PWM duty cycle % (0-100)

print "Turning motor CW direction (full speed)"
GPIO.output(green,GPIO.HIGH) #turn green light on
GPIO.output(blue,GPIO.HIGH) #turn blue light on
GPIO.output(motor_pos,GPIO.HIGH)
GPIO.output(motor_neg,GPIO.LOW)
GPIO.output(motor1_enable,GPIO.HIGH)
time.sleep(5)
GPIO.output(green,GPIO.LOW) #turn green light off
GPIO.output(blue,GPIO.LOW) #turn blue light off

#stop motor for 2 seconds
GPIO.output(red,GPIO.HIGH)
stop_motor(motor1_enable)
GPIO.output(red,GPIO.LOW)

print "Turning motor CCW directon (full speed)"
GPIO.output(green,GPIO.HIGH) #turn green light on
GPIO.output(yeller,GPIO.HIGH) #turn yeller light on
GPIO.output(motor_pos,GPIO.LOW)
GPIO.output(motor_neg,GPIO.HIGH)
GPIO.output(motor1_enable,GPIO.HIGH)
time.sleep(7)
GPIO.output(green,GPIO.LOW) #turn green light off
GPIO.output(yeller,GPIO.LOW) #turn yeller light off


print "Turning motor CW direction (reduced speed)"
GPIO.output(green,GPIO.HIGH) #turn green light on
GPIO.output(blue,GPIO.HIGH) #turn blue light on
pwm.start(dc)
GPIO.output(motor_neg,GPIO.LOW)
GPIO.output(motor1_enable,GPIO.HIGH)
time.sleep(10)
pwm.stop() 
GPIO.output(green,GPIO.LOW) #turn green light off
GPIO.output(blue,GPIO.LOW) #turn blue light off

#stop motor for 3 seconds
GPIO.output(red,GPIO.HIGH) #turn red light on
stop_motor(motor1_enable)
time.sleep(1)
GPIO.output(red,GPIO.LOW) #turn red light off

print "Turning motor CCW direction (reduced speed)"
GPIO.output(green,GPIO.HIGH) #turn green light on
GPIO.output(yeller,GPIO.HIGH) #turn yeller light on
pwm.start(dc)
GPIO.output(motor_neg,GPIO.HIGH)
GPIO.output(motor1_enable,GPIO.HIGH)
time.sleep(6)
pwm.stop() 
GPIO.output(green,GPIO.LOW) #turn green light off
GPIO.output(yeller,GPIO.LOW) #turn yeller light off

# Cleanup the gpio pins
GPIO.cleanup()

# Notes on PWM duty cylce
# The DC can be changed using: pwm.ChangeDutyCycle(dc_new), where dc_new
# is the new DC you wish to use. 
