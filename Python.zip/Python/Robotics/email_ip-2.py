import smtplib
import socket
import time

######################## USER DEFINED PARAMETERS #######################
gmail_user = "behrendtgabe@gmail.com"	# Enter your gmail account (preferable group account), make sure to include @gmail.com and the "" marks. 
gmail_password = "gabe1998"			# Enter your gmail password including the "" marks. (now you see why I recomend using a group email account). 
send_to = ["gabriel-behrendt@uiowa.edu"]  		# Enter the email address you want to send it to, again include the "" marks. 
									# To send the IP address to multiple addresses enter each followed by a comman.
									# For example ["ME4140_ROCKS@gmail.com", "herky@uiowa.edu", "youGetThePoint@hotmail.com", ...] 
######################## USER DEFINED PARAMETERS #######################

update_freq = 15*60 # minutes*seconds/min = seconds
prev_ip_addr = ""
error=1
while True:
	ts = time.gmtime()
	print time.strftime("%c", ts) # ISO format
	print '\tChecking if a new IP address has been assigned'
	print '\tPrevious IP address = ', prev_ip_addr
	# Get the router assigned IP address
	s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	s.connect(("8.8.8.8", 80))
	ip_addr = s.getsockname()[0]
	s.close()
	print "\tCurrent IP address is: ", ip_addr
		
	if ip_addr != prev_ip_addr:
		prev_ip_addr = ip_addr
                print '\tNew IP address assigned'
		print '\tSending email with new IP address!'
		sent_from = gmail_user  
		to = send_to      
		subject = 'RPI IP address'  
		body = "Address = " + str(ip_addr)

		email_text = """\  
		From: %s  
		To: %s  
		Subject: %s

		%s
		""" % (sent_from, ", ".join(to), subject, body)

		try:  
			server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
			server.ehlo()
			server.login(gmail_user, gmail_password)
			server.sendmail(sent_from, to, email_text)
			server.close()
			error=0
			print '\tEmail sent!\n'
		except:  
			error=1
			print '\n\tSomething went wrong...\n \n\tCheck the following: \n'
			print '\t\t1) Email address contains @domain.com.'
			print '\t\t2) Email address is in between "" marks.'
			print '\t\t3) Security settings have been modified on gmail account.'
	else:
		if error == 0:
			print '\tNo change in the IP address.\n'
		time.sleep(update_freq)
