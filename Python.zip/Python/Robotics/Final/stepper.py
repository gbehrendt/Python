
# This script provides basic stepper motor control using the L239D chip. 
# CW and counter CCW are referenced when looking at the motor from the shaft side. 

import RPi.GPIO as GPIO	
import time
import myFuncs

# Setting the GPIO pin description to BCM and turning off warnigns
GPIO.setmode(GPIO.BOARD)			
GPIO.setwarnings(False)	

# Pin assignments
# Variable      RPi (BCM)		L239D (pin #)
enable_pin 		= 26			# 1
coil_A_1_pin	= 4				# 2
coil_A_2_pin	= 17			# 7
coil_B_1_pin	= 23			# 15
coil_B_2_pin 	= 24			# 10

# Setting GPIO pins to output mode
GPIO.setup(enable_pin, GPIO.OUT)
GPIO.setup(coil_A_1_pin, GPIO.OUT)
GPIO.setup(coil_A_2_pin, GPIO.OUT)
GPIO.setup(coil_B_1_pin, GPIO.OUT)
GPIO.setup(coil_B_2_pin, GPIO.OUT)

# Enable the motor
GPIO.output(enable_pin, 1)

try:
	while True:
		myFuncs.stop_motor(enable_pin)
		delay = 5.0/1000 		# milliseconds
		smalldelay = 2.0/1000   #Faster speed
		
		
		
except:
	myFuncs.setStep(0,0,0,0)
	GPIO.cleanup()
	
