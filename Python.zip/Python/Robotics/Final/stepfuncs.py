import socket
from socket import SHUT_RDWR
import RPi.GPIO as GPIO	
import time
import sys

# Pin assignments
# Variable      RPi (BOARD)		L239D (pin #)
coil_A_1_pin	= 31			# 2
coil_A_2_pin	= 33			# 7
coil_B_1_pin	= 35			# 15
coil_B_2_pin 	= 37			# 10

def Gohome(counter):
	print 'Moving ',counter,' steps to home'
	if(counter<0):
		CW(5.0/1000,counter*-1)
	elif(counter>0):
		CCW(5.0/1000,counter)
	
	

def CCW(delay, steps): 
	print 'Moving CCW',steps,'steps'
	for i in range(0, steps):
		setStep(1, 0, 1, 0)
		time.sleep(delay)
		setStep(0, 1, 1, 0)
		time.sleep(delay)
		setStep(0, 1, 0, 1)
		time.sleep(delay)
		setStep(1, 0, 0, 1)
		time.sleep(delay)
	
 
def CW(delay, steps): 
	print 'Moving CW',steps,'steps'
	for i in range(0, steps):
		setStep(1, 0, 0, 1)
		time.sleep(delay)
		setStep(0, 1, 0, 1)
		time.sleep(delay)
		setStep(0, 1, 1, 0)
		time.sleep(delay)
		setStep(1, 0, 1, 0)
		time.sleep(delay)

 
def setStep(w1, w2, w3, w4):
	GPIO.output(coil_A_1_pin, w1)
	GPIO.output(coil_A_2_pin, w2)
	GPIO.output(coil_B_1_pin, w3)
	GPIO.output(coil_B_2_pin, w4)
	

def getIP():
	s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	s.connect(("8.8.8.8",80))
	ip_address = s.getsockname()[0]
	s.close()
	return ip_address

