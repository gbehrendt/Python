import RPi.GPIO as GPIO
import socket
from socket import SHUT_RDWR
import time
import sys
import stepfuncs

# Setting the GPIO pin description to BOARD and turning off warnings
GPIO.setmode(GPIO.BOARD)			
GPIO.setwarnings(False)	

# Pin assignments
# Variable      RPi (BOARD)		L239D (pin #)
coil_A_1_pin	= 31			# 2
coil_A_2_pin	= 33			# 7
coil_B_1_pin	= 35			# 15
coil_B_2_pin 	= 37			# 
counter 	= 0


# Setting GPIO pins to output mode
GPIO.setup(coil_A_1_pin, GPIO.OUT)
GPIO.setup(coil_A_2_pin, GPIO.OUT)
GPIO.setup(coil_B_1_pin, GPIO.OUT)
GPIO.setup(coil_B_2_pin, GPIO.OUT)





server_ip = stepfuncs.getIP()
print 'Current IP: ', server_ip

TCP_IP = server_ip
TCP_PORT = 5005
BUFFER_SIZE = 1024  # Normally 1024, but we want fast response

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((TCP_IP, TCP_PORT))
s.listen(1)



Matrix=[ [1,2,3,'A'],
         [4,5,6,'B'],
         [7,8,9,'C'],
	 ['*',0,'#','D'] ]
		 
row=[7,11,13,15]
col=[12,16,18,22]


for j in range(4):
	GPIO.setup(col[j],GPIO.OUT)
	GPIO.output(col[j],1)

for i in range(4):
	GPIO.setup(row[i],GPIO.IN, pull_up_down = GPIO.PUD_UP)
	
try:
	while(True):
		#Phone control commands
		conn, addr = s.accept()
		for i in xrange(10):
			data = conn.recv(BUFFER_SIZE) # will a string
			time.sleep(.1)
			if len(data) > 0:
				if data=='a':
					#if counter == 0
					#	print 'can not go up'
					#	conn.send('cant go down anymore')
					print data
					conn.send('a pressed')
					time.sleep(.5)
					stepfuncs.CW(2.0/1000, 830)
				elif data=='b':
					print data
					conn.send('b pressed')
					time.sleep(.5)
					stepfuncs.CCW(2.0/1000, 800)
					
				elif data=='h':
					print data
					conn.send('h pressed')
				elif data == 'c':
					conn.send('Closing network connecton.') # send message to the client
					GPIO.cleanup()
					time.sleep(1)
					time.sleep(1)
					conn.close()
					time.sleep(1)
					sys.exit()
				else:
					conn.send('Invalid request!')
		
		#Remote control commands
		for j in range(4):
			GPIO.output(col[j],0)
			for i in range(4):
				if GPIO.input(row[i]) == 0:
					print Matrix[i][j]
					if(Matrix[i][j] == 1):
						print i,j  #Add stepper code here
					elif(Matrix[i][j] == 2):
						print i,j  #Add stepper code here
					elif(Matrix[i][j] == 3):
						print i,j  #Add stepper code here
					while(GPIO.input(row[i]) == 0):
						pass
			GPIO.output(col[j],1)
		
except KeyboardInterrupt:
	conn.send('Closing network connecton.')
try:
        GPIO.cleanup()
        time.sleep(1)
        time.sleep(1)
        conn.close()
        time.sleep(1)
except:
        pass


